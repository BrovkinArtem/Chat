package com.example.chat

data class User(
    val name: String? = null,
    val message: String? = null
)
